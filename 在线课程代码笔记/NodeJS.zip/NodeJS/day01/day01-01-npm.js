//node -v  检测nodeJS版本
//npm -v   检测npm的版本

//npm 是nodejs的包管理器

//下载包   jquery  bootstrap等等都是包

//cnpm install -g supervisor  安装nodejs自启动工具   -g全局安装

//npm install 包名@版本号  如果 ：下载jquery       npm install jquery@1.12.4
//npm uninstall 包名   卸载包
//npm list  查看当前目录下已经安装的node包
//npm help  查看帮助命令


