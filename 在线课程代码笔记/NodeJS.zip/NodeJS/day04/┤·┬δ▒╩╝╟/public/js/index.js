let oBtn=document.getElementById("btn");
let oImg=document.getElementById("img");
oBtn.onclick=function(){
	oImg.style.width="600px"
}
