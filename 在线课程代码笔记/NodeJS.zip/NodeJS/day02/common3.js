let oFoo=require("foo");    //foo对应node_module里面的foo文件名，可以不用加单位
console.log(oFoo)  //{ abc: '我是node_modules文件夹中的foo文件' }

//foo这个文件在node_modules文件夹中，直接其效果
