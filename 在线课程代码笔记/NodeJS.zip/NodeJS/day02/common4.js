let head=require("header/header");
console.log(head) //{ abc: '我是node_modules文件夹中的header文件夹中的header文件' }
