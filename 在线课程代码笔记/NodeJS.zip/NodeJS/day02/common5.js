let nav=require("nav")  
console.log(nav) //{ abc: '我是node_modules文件夹中的nav文件夹中的index文件' }
