let tools={
	sum:function(x,y){
		return x+y
	},
	fn:function(){
		return "我是一个工具文件，可以在这里定义方法"
	}
}

module.exports=tools