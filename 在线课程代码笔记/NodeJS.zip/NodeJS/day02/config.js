let str="我是一个配置文件";

//暴露变量
//exports.abc=str  //暴露模块     abc就是以后使用时候得到对象的属性

module.exports=str


//exports  暴露一个对象

//modele.exports  暴露内容